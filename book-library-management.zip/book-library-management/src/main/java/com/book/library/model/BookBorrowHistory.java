package com.book.library.model;

import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@ToString
@Table(name="BookBorrowHistory")

public class BookBorrowHistory {
	
	private String BookId;
	private String UserId;
	private String DateOfIssue;
	private String DateOfReturn;
	private String TotalFine;



}
