package com.book.library.controller;

public enum BookStatus {
	
	AVAILABLE,BORROWED,OVERDUE
}